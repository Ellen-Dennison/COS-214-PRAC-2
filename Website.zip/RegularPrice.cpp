#include "RegularPrice.h"

double RegularPrice::applyDiscount(){
  return pizza->getPrice()*1.0;
}