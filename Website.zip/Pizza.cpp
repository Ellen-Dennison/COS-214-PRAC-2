#include "Pizza.h"
#include <iostream>
using namespace std;

void Pizza::printPizza(){
  cout<<"Default Pizza print"<<endl;
}