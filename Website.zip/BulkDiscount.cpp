#include "BulkDiscount.h"

double BulkDiscount::applyDiscount(){
  return pizza->getPrice()*0.9;
}

